<html>
    <head>
        <title>Menuiserie Collaborative</title>   
        <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/bootstrap.css">
        <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.css">
    </head>

    <body>

