<?php

echo "<h1>$titre</h1>" ;
